<?php
    include './database.php';
    $jobObj = new database();
    if (isset($_POST['submit'])) {
        $jobObj->insertData($_POST);
    }
?>


<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Bio-data</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    </head>
    <body>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
        <link href="./css/style.css" rel="stylesheet">

        <!--adding global header-->
        <?php require ('./header.php'); ?>



        <div class="background d-flex justify-content-center">
            <div class="dimensions">
                <div class="main-form">
                    <?php
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        $fname         = trim($_POST['fname']);
                        $mobile        = trim($_POST['mobile']);
                        $email         = trim($_POST['email']);
                        $father_name   = trim($_POST['father_name']);
                        $gender        = $_POST['gender'];
                        $dob           = trim($_POST['dob']);
                        $religion      = trim($_POST['religion']);
                        $lang          = trim($_POST['lang']);
                        $m_status      = $_POST['m_status'];
                        $qualification = trim($_POST['qualification']);
                        $exp           = trim($_POST['experience']);
                        $address       = trim($_POST['address']);

                         $error = "";
                        if (empty($fname)) {
                            $error = "Full name is required";
                        } else if (empty($mobile)) {
                            $error = "Mobile number is required";
                        } else if (!is_numeric($mobile)){
                            $error = "Mobile number can only have numbers";
                        } else if (strlen($mobile) != 10){
                            $error = "Mobile number can have only 10 digits";
                        } else if (empty($email)) { // Email
                            $error = "An email is required";
                        } else if (!preg_match("/^[_.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+.)+[a-zA-Z]{2,6}$/i", $email)) {
                            $error = "Please use the correct email format";
                        } else if (empty($father_name)) {
                            $error = "Father's name is required";
                        } else if (empty($gender)) {
                            $error = "Choose your gender";
                        } else if (empty($dob)) {
                            $error = "Add your birth date";
                        } else if (empty($religion)) {
                            $error = "Religion is required";
                        } else if (empty($lang)) {
                            $error = "Language is required";
                        } else if (empty($m_status)) {
                            $error = "Choose your marital status";
                        } else if (empty($qualification)) {
                            $error = "Qualification is required";
                        } else if (empty($experience)) {
                            $error = "Experience is required";
                        } else if (empty($address)) {
                            $error = "Address is required";
                        } else {
                            ?>
                            <!-- to inform that the details are submitted -->
                            <script>
                                alert('You are successfully registered');
                            </script>

                    <?php

                        }
                    }

                    ?>
                    <form class="form-space" action="index.php" method="post">

                        <div class="d-flex justify-content-center">
                            <h1 class="text-white">Bio-data</h1>
                        </div>

                        <div class="row mb-3">
                            <div class="col-12">
                                <label for="a1" class="form-label text-white fw-bold">Full Name</label>
                                <input type="text" class="form-control text-white bg-dark" name="fname" id="a1" placeholder="Jonathan Linn" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-6">
                                <label for="b1" class="form-label text-white fw-bold">Mobile</label>
                                <input type="tel" class="form-control text-white bg-dark" name="mobile" id="b1" placeholder="9876543210" required>
                            </div>

                            <div class="col-6">
                                <label for="b2" class="form-label text-white fw-bold">Email</label>
                                <input type="email" class="form-control text-white bg-dark" name="email" id="b2" placeholder="abc@gmail.com" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-12">
                                <label for="c1" class="form-label text-white fw-bold">Father's Name</label>
                                <input type="text" class="edit1 form-control text-white bg-dark" name="father_name" id="c1" placeholder="Joseph Linn" required>
                            </div>
                        </div>


                        <div class="radio bg-dark border border-light mb-3">
                            <label class="form-label text-secondary fw-bold pe-3">Gender</label>
                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="gender" value="Male" id="d1" required>
                                <label for="d1" class="form-check-label text-secondary fw-bold">Male</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="gender" value="Female" id="d2" required>
                                <label for="d2" class="form-check-label text-secondary fw-bold">Female</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="gender" value="Other" id="d3" required>
                                <label for="d3" class="form-check-label text-secondary fw-bold">Other</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="gender" value="Not to Say" id="d4" required>
                                <label for="d4" class="form-check-label text-secondary fw-bold">Prefer not to say</label>
                            </div>

                        </div>

                        <div class="row mb-3">
                            <div class="col-4">
                                <label for="e1" class="form-label text-white fw-bold">Date of Birth</label>
                                <input type="date" id="e1" class="form-control text-secondary bg-dark" name="dob" required>
                            </div>

                            <div class="col-4">
                                <label for="e2" class="form-label text-white fw-bold">Religion</label>
                                <input type="text" id="e2" class="form-control text-white bg-dark" name="religion" placeholder="Christian" required>
                            </div>

                            <div class="col-4">
                                <label for="e3" class="form-label text-white fw-bold">Languages Known</label>
                                <input type="text" id="e3" class="edit1 form-control text-white bg-dark" name="lang" placeholder="English" required>
                            </div>
                        </div>

                        <div class="radio border border-light bg-dark mb-3">
                            <label class="form-label text-secondary fw-bold pe-3">Marital Status</label>
                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="m_status" value="Married" id="f1" required>
                                <label for="f1" class="form-check-label text-secondary fw-bold">Married</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="m_status" value="Unmarried" id="f2" required>
                                <label for="f2" class="form-check-label text-secondary fw-bold">Unmarried</label>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-12">
                                <label for="g1" class="form-label text-white fw-bold">Qualifications</label>
                                <input type="text" class="form-control text-white bg-dark" name="qualification" id="g1" placeholder="Skills here" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-12">
                                <label for="h1" class="form-label text-white fw-bold">Experience</label>
                                <input type="text" class="form-control text-white bg-dark" name="experience" id="h1" placeholder="Companies worked in" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-12">
                                <label for="i1" class="form-label text-white fw-bold">Address</label>
                                <input type="text" class="form-control text-white bg-dark" name="address" id="i1" placeholder="123 My House" required>
                            </div>
                        </div>


                        <input type="submit" name="submit" value="UPLOAD" class="btn border border-light bg-dark text-white col-4 fw-bold">

                        <!-- adding error if something is not right -->
                        <?php
                        echo '$error';
                        ?>

                    </form>
                </div>
            </div>
        </div>
        <?php
            require './footer.php';
        ?>

    </body>
</html>
