<?php
    include './database.php';
    $jobObj = new database();

    // adding delete to delete existing data
    if (isset($_GET['deleteID']) && !empty($_GET['deleteID'])){
        $deleteID = $_GET['deleteid'];
        $jobObj->deleteRecord($deleteID);
    }
?>

    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Bio-data</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    </head>
    <body>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
        <link href="./css/style.css" rel="stylesheet">

        <!-- fontawesome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

        <!--adding global header-->
        <?php require './header.php'; ?>
        <div class="p-5 text-center1 bg-light" style="margin-top: 58px;background: -webkit-linear-gradient(left, #3931af, #00c6ff);">
            <h1 class="mb-3">Your Details</h1>
            <h2>
                <a href="index.php" style="float:right;"><button><i class="fas fa-plus"></i></button></a>
            </h2>

            <main class="con">
                <?php
                if(isset($_GET['msg1']) == "insert"){
                    echo "<div class='alert alert-success alert-dismissible'>
                              <button type='button' class='close' data-dismiss='alert'>X</button>
                              Your record has been added.
                          </div>";
                }
                if(isset($_GET['msg2']) == "update"){
                    echo "<div class='alert alert-success alert-dismissible'>
                              <button type='button' class='close' data-dismiss='alert'>X</button>
                              Your record has been updated.
                          </div>";
                }
                if(isset($_GET['msg3']) == "delete"){
                    echo "<div class='alert alert-success alert-dismissible'>
                              <button type='button' class='close' data-dismiss='alert'>X</button>
                              Your record has been deleted.
                          </div>";
                }
                ?>
                <div class="row">
                    <table class="table table-hover table-dark table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>FULL NAME</th>
                                <th>CONTACT</th>
                                <th>EMAIL</th>
                                <th>FATHER's NAME</th>
                                <th>GENDER</th>
                                <th>DOB</th>
                                <th>RELIGION</th>
                                <th>LANGUAGES</th>
                                <th>MARITAL STATUS</th>
                                <th>QUALIFICATIONS</th>
                                <th>EXPERIENCE</th>
                                <th>ADDRESS</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $job = $jobObj->displayData();
                                foreach ($job as $res){
                            ?>


                            <tr>
                                <td><?php echo $res['id']; ?></td>
                                <td><?php echo $res['fname']; ?></td>
                                <td><?php echo $res['mobile']; ?></td>
                                <td><?php echo $res['email']; ?></td>
                                <td><?php echo $res['father_name']; ?></td>
                                <td><?php echo $res['gender']; ?></td>
                                <td><?php echo $res['dob']; ?></td>
                                <td><?php echo $res['religion']; ?></td>
                                <td><?php echo $res['lang']; ?></td>
                                <td><?php echo $res['m_status']; ?></td>
                                <td><?php echo $res['qualification']; ?></td>
                                <td><?php echo $res['experience']; ?></td>
                                <td><?php echo $res['address']; ?></td>

                                <td>
                                    <button class="btn btn-primary mr-2">
                                        <a href="./edit.php?editId=<?php echo $res['id']; ?>">
                                            <i class="fa fa-pencil text-white"></i>
                                        </a>
                                    </button>
                                    <button class="btn btn-primary mr-2">
                                        <a href="./view.php?deleteId=<?php echo $res['id']; ?>">
                                            <i class="fa fa-trash text-white"></i>
                                        </a>
                                    </button>
                                </td>
                            </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
        <?php
            require './footer.php';
        ?>
    </body>
</html>




