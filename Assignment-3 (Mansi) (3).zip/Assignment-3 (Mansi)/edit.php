<?php
    include "./database.php";
    $jobObj = new database();
    if (isset($_GET['editId']) && !empty($_GET['editId'])){
        $editId = $_GET['editId'];
        $res = $jobObj->displayRecordById($editId);
    }
    if (isset($_POST['update'])) {
        $jobObj->updateRecord($_POST);;
    }
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Bio-data</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    </head>
    <body>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
        <link href="./css/style.css" rel="stylesheet">

        <!-- fontawesome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

        <!--adding global header-->
        <?php require './header.php'; ?>
        <div class="background d-flex justify-content-center">
            <div class="dimensions">
                <div class="main-form">
                    <?php
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        $fname = trim($_POST['ufname']);
                        $mobile = trim($_POST['umobile']);
                        $email = trim($_POST['uemail']);
                        $father_name = trim($_POST['ufather_name']);
                        $gender = $_POST['ugender'];
                        $dob = trim($_POST['udob']);
                        $religion = trim($_POST['ureligion']);
                        $lang = trim($_POST['ulang']);
                        $m_status = $_POST['um_status'];
                        $qualification = trim($_POST['uqualification']);
                        $experience = trim($_POST['uexperience']);
                        $address = trim($_POST['uaddress']);

                        $error1 = "";
                        if (empty($fname)) {
                            $error1 = "Full name is required";
                        } else if (empty($mobile)) {
                            $error1 = "Mobile number is required";
                        } else if (!is_numeric($mobile)){
                            $error1 = "Mobile number can only have numbers";
                        } else if (strlen($mobile) != 10){
                            $error1 = "Mobile number can have only 10 digits";
                        } else if (empty($email)) { // Email
                            $error1 = "An email is required";
                        } else if (!preg_match("/^[_.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+.)+[a-zA-Z]{2,6}$/i", $email)) {
                            $error1 = "Please use the correct email format";
                        } else if (empty($father_name)) {
                            $error1 = "Father's name is required";
                        } else if (empty($gender)) {
                            $error1 = "Choose your gender";
                        } else if (empty($dob)) {
                            $error1 = "Add your birth date";
                        } else if (empty($religion)) {
                            $error1 = "Religion is required";
                        } else if (empty($lang)) {
                            $error1 = "Language is required";
                        } else if (empty($m_status)) {
                            $error1 = "Choose your marital status";
                        } else if (empty($qualification)) {
                            $error1 = "Qualification is required";
                        } else if (empty($experience)) {
                            $error1 = "Experience is required";
                        } else if (empty($address)) {
                            $error1 = "Address is required";
                        } else {
                            ?>
                            <!-- to inform that the details are submitted -->
                            <script>
                                alert('Your profile is updated');
                            </script>

                            <?php

                        }
                    }

                    ?>
                    <form class="form-space" action="edit.php" method="POST">

                        <div class="d-flex justify-content-center">
                            <h1 class="text-white">UPDATE PROFILE</h1>
                        </div>

                        <div class="row mb-3">
                            <div class="col-12">
                                <label for="a1" class="form-label text-white fw-bold">Full Name</label>
                                <input type="text" class="form-control text-white bg-dark" name="ufname" id="a1" value="<?php echo $res['fname']; ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-6">
                                <label for="b1" class="form-label text-white fw-bold">Mobile</label>
                                <input type="tel" class="form-control text-white bg-dark" name="umobile" id="b1" value="<?php echo $res['mobile']; ?>" required>
                            </div>

                            <div class="col-6">
                                <label for="b2" class="form-label text-white fw-bold">Email</label>
                                <input type="email" class="form-control text-white bg-dark" name="uemail" id="b2" value="<?php echo $res['email']; ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-12">
                                <label for="c1" class="form-label text-white fw-bold">Father's Name</label>
                                <input type="text" class="edit1 form-control text-white bg-dark" name="ufather_name" id="c1" value="<?php echo $res['father_name']; ?>" required>
                            </div>
                        </div>


                        <div class="radio bg-dark border border-light mb-3">
                            <label class="form-label text-secondary fw-bold pe-3">Gender</label>
                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="ugender" value="Male" <?php echo ($res['gender']=='Male')?"checked":""; ?> id="d1" required>
                                <label for="d1" class="form-check-label text-secondary fw-bold">Male</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="ugender" value="Female" <?php echo ($res['gender']=='Female')?"checked":""; ?> id="d2" required>
                                <label for="d2" class="form-check-label text-secondary fw-bold">Female</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="ugender" value="Other" <?php echo ($res['gender']=='Other')?"checked":""; ?> id="d3" required>
                                <label for="d3" class="form-check-label text-secondary fw-bold">Other</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="ugender" value="Not To Say" <?php echo ($res['gender']=='Not To Say')?"checked":""; required?> id="d4" required>
                                <label for="d4" class="form-check-label text-secondary fw-bold">Prefer not to say</label>
                            </div>

                        </div>

                        <div class="row mb-3">
                            <div class="col-4">
                                <label for="e1" class="form-label text-white fw-bold">Date of Birth</label>
                                <input type="date" id="e1" class="form-control text-secondary bg-dark" name="udob" value="<?php echo $res['dob']; ?>" required>
                            </div>

                            <div class="col-4">
                                <label for="e2" class="form-label text-white fw-bold">Religion</label>
                                <input type="text" id="e2" class="form-control text-white bg-dark" name="ureligion" value="<?php echo $res['religion']; ?>" required>
                            </div>

                            <div class="col-4">
                                <label for="e3" class="form-label text-white fw-bold">Languages Known</label>
                                <input type="text" id="e3" class="edit1 form-control text-white bg-dark" name="ulang" value="<?php echo $res['lang']; ?>" required>
                            </div>
                        </div>

                        <div class="radio border border-light bg-dark mb-3">
                            <label class="form-label text-secondary fw-bold pe-3">Marital Status</label>
                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="um_status" value="Married" <?php echo ($res['m_status']=='Married')?"checked":""; ?> id="f1" required>
                                <label for="f1" class="form-check-label text-secondary fw-bold">Married</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="um_status" value="Unmarried" <?php echo ($res['m_status']=='Unmarried')?"checked":""; ?> id="f2" required>
                                <label for="f2" class="form-check-label text-secondary fw-bold">Unmarried</label>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-12">
                                <label for="g1" class="form-label text-white fw-bold">Qualifications</label>
                                <input type="text" class="form-control text-white bg-dark" name="uqualification" id="g1" value="<?php echo $res['qualification']; ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-12">
                                <label for="h1" class="form-label text-white fw-bold">Experience</label>
                                <input type="text" class="form-control text-white bg-dark" name="uexperience" id="h1" value="<?php echo $res['exp']; ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-12">
                                <label for="i1" class="form-label text-white fw-bold">Address</label>
                                <input type="text" class="form-control text-white bg-dark" name="uaddress" id="i1" value="<?php echo $res['address']; ?>" required>
                            </div>
                        </div>

                        <div class=""row mb-3>
                            <div class="d-flex justify-content-center mt-3">
                                <input type="hidden" name="id" value="<?php echo $res['id']; ?>">
                                <input type="submit" name="update" value="UPDATE" class="btn border border-light bg-dark text-white col-4 fw-bold">
                            </div>
                        </div>

                        <!-- adding error if something is not right -->
                        <?php
                            echo '$error1';
                        ?>

                    </form>

                </div>
            </div>
        </div>
        <?php
            require './footer.php';
        ?>
    </body>
</html>