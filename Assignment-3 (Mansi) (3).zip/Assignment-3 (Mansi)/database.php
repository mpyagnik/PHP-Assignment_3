<?php
class database{
    // adding sql server
    public $servername = "172.31.22.43";
    public $username = "Mansi200515355";
    public $password = "yEGYabhwlb";
    public $dbname = "Mansi200515355";
    public $conn;
    // creating connections
    public function __construct()
    {
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
        if (mysqli_connect_error()) {
            trigger_error("Failed to connect:" . mysqli_connect_error());
        } else {
            return $this->conn;
        }
    }

    // function to insert data into the table (INSERT function)
    public function insertData($post)
    {
        $fname = $this->conn->real_escape_string($_POST['fname']);
        $mobile = $this->conn->real_escape_string($_POST['mobile']);
        $email = $this->conn->real_escape_string($_POST['email']);
        $father_name = $this->conn->real_escape_string($_POST['father_name']);
        $gender = $this->conn->real_escape_string($_POST['gender']);
        $dob = $this->conn->real_escape_string($_POST['dob']);
        $religion = $this->conn->real_escape_string($_POST['religion']);
        $lang = $this->conn->real_escape_string($_POST['lang']);
        $m_status = $this->conn->real_escape_string($_POST['m_status']);
        $qualification = $this->conn->real_escape_string($_POST['qualification']);
        $experience = $this->conn->real_escape_string($_POST['experience']);
        $address = $this->conn->real_escape_string($_POST['address']);
        $query = "INSERT INTO job(fname, mobile, email, father_name, gender, dob, religion, lang, m_status, qualification, experience, address) VALUES ('$fname', '$mobile', '$email', '$father_name', '$gender', '$dob', '$religion', '$lang', '$m_status', '$qualification', '$experience', '$address')";
        $sql = $this->conn->query($query);
        if ($sql == true){
            // shows if data is successfully inserted
            header("Location:index.php?msg1=insert");
        }else{
            // shows error
            echo "Cannot add your data";
        }
    }

    // fetching the data from the table (READ function)
    public function displayData(){
        $query = "SELECT * FROM job";
        // using limit 1 to only load 1 inserted data
        $result = $this->conn->query($query);
        if ($result->num_rows > 0) {
            $data = array();
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            return $data;
        }else{
           echo "No profile found";
        }
    }
    // update and read (UPDATE function)
    public function displayRecordById($id){
        $query = "SELECT * FROM job WHERE id = '$id'";
        $result = $this->conn->query($query);
        if ($result->num_rows > 0){
            $row = $result->fetch_assoc();
            return $row;
        }else{
            echo "No profile found!!";
        }
    }
    public function updateRecord($postData){
        $fname = $this->conn->real_escape_string($_POST['ufname']);
        $mobile = $this->conn->real_escape_string($_POST['umobile']);
        $email = $this->conn->real_escape_string($_POST['uemail']);
        $father_name = $this->conn->real_escape_string($_POST['ufather_name']);
        $gender = $this->conn->real_escape_string($_POST['ugender']);
        $dob = $this->conn->real_escape_string($_POST['udob']);
        $religion = $this->conn->real_escape_string($_POST['ureligion']);
        $lang = $this->conn->real_escape_string($_POST['ulang']);
        $m_status = $this->conn->real_escape_string($_POST['um_status']);
        $qualification = $this->conn->real_escape_string($_POST['uqualification']);
        $experience = $this->conn->real_escape_string($_POST['uexperience']);
        $address = $this->conn->real_escape_string($_POST['uaddress']);
        $id = $this->conn->real_escape_string($_POST['id']);
        if (!empty($id) && !empty($postData)){
            $query = "UPDATE job SET fname = '$fname', mobile = '$mobile', email = '$email', father_name = '$father_name', gender = '$gender', dob = '$dob', religion = '$religion', lang = '$lang', m_status = '$m_status', qualification = '$qualification', experience = '$experience', address = '$address' WHERE id = '$id'";
            $sql = $this->conn->query($query);
            if($sql == true){
                // shows message if data is successfully updated
                header("Location:index.php?msg2=update");
            }else{
                // shows error
                echo "Could not update your profile";
            }
        }
    }
    // creating delete function (DELETE function)
    public function deleteRecord($id){
        $query = "DELETE FROM job WHERE id = '$id'";
        $sql = $this->conn->query($query);
        if($sql == true){
            // shows message if data is successfully deleted
            header("Location:index.php?msg3=delete");
        }else{
            // shows error
            echo "Could not delete the profile";
        }
    }
}

